const IP = "0.0.0.0"

function checkCookie(){
    let cookies = document.cookie.split("=")
    document.getElementById("title").innerHTML = "Welcome " + cookies[3]
}




function history(){
    let url = 'http://' + IP + ":5000/getOrderOverView/"
    //console.log(url)
    fetch(url).then((resp) => resp.json()).then(function(data) {
        console.log(data)
        if (data.csv != undefined){
            return data.csv
            //alert("nice")
        }
        else
        alert("Server Error")
    }).then(function(tabledata){
        var table = new Tabulator("#container", {
            responsiveLayout:"hide",
            data:tabledata, //assign data to table
            layout:"fitColumns", //fit columns to width of table (optional)
            tooltips:true,            //show tool tips on cells
            pagination:"local",       //paginate the data
            paginationSize:7,         //allow 7 rows per page of data
            columns:[ //Define Table Columns
                {title:"Order ID", field:"id", align:"right", sorter:"number"},
                {title:"Employee", field:"employee_id",align:"right", sorter:"number"},
                {title:"Date", field:"order_date",align:"right", sorter:"string"},
                {title:"Total", field:"total",align:"right", sorter:"number"},
            ]
        });
        //console.log(tabledata)
        let order_date= []
        let sold_on_date= []
        for (i in tabledata){
            //console.log(tabledata[i])
            order_date.push(tabledata[i]["order_date"])
            sold_on_date.push(tabledata[i]["total"])
        }
        console.log(order_date)
        console.log(sold_on_date)
        new Chart(document.getElementById("bar-chart"), {
            type: 'bar',
            data: {
                labels: order_date,
                datasets: [{
                    label: 'USD',
                    data: sold_on_date,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)',
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)',
                        'rgba(255,99,132,1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                legend: { display: false },
                title: {
                    display: true,
                    text: 'Total sales by day'
                }
            }
        });
    });


}











function inventory(){
    let url = 'http://' + IP + ":5000/getQuantities/"
    //console.log(url)
    fetch(url).then((resp) => resp.json()).then(function(data) {
        console.log(data)
        if (data.csv != undefined){
            return data.csv
            //alert("nice")
        }
        else
        alert("Server Error")
    }).then(function(tabledata){
        var table = new Tabulator("#container", {
            responsiveLayout:"hide",
            data:tabledata, //assign data to table
            layout:"fitColumns", //fit columns to width of table (optional)
            tooltips:true,            //show tool tips on cells
            pagination:"local",       //paginate the data
            paginationSize:7,         //allow 7 rows per page of data
            columns:[ //Define Table Columns


                {title:"Product ID", field:"product_id", align:"right", sorter:"string"},
                {title:"Product", field:"name",align:"left", sorter:"string"},
                {title:"In Stock", field:"quantity_in_stock",align:"right", sorter:"number"},
                {title:"Unit Price", field:"unit_price",align:"right", sorter:"number"},
            ]
        });
    })

}
