const IP = "0.0.0.0"
function login() {
    if (document.getElementById("password").value != "" && document.getElementById("username").value != ""){
        let url = 'http://' + IP + ":5000/login/" + document.getElementById("username").value + "/" + document.getElementById("password").value
        console.log(url)
        fetch(url).then((resp) => resp.json()).then(function(data) {
            //console.log(data)
            if (data.cookie != undefined){
                document.cookie = "username=" + data.cookie;
                checkCookie()
                //alert("nice")
            }
            else
            alert("Wrong credentials, please try again")
        })
    }

    if (document.getElementById("password").value == ""){
        console.log(document.getElementById("password").style.color)
        document.getElementById("password_text").style.color = "red"
    }
    else{
        document.getElementById("password_text").style.color = "#4c779c"
    }
    if (document.getElementById("username").value == ""){
        document.getElementById("username_text").style.color = "red"
    }
    else{
        document.getElementById("username_text").style.color = "#4c779c"
    }
}

document.addEventListener("keydown", function (e) {
    if (e.keyCode === 13) {  //checks whether the pressed key is "Enter"
        login();
    }
});


function checkCookie() {
    let cookies = document.cookie.split("=")
    if(cookies[1] != undefined){
        let url = 'http://' + IP + ":5000/getNameByHash/" + cookies[1]
        //console.log(url)
        fetch(url).then((resp) => resp.json()).then(function(data) {
            //console.log(data)
            if (data.employee_name != undefined){
                if (cookies[2]==undefined)
                    document.cookie += "=employee_name=" + data.employee_name;
                window.location.replace("main.html")
                //alert("nice")
            }
        })
    }
}
